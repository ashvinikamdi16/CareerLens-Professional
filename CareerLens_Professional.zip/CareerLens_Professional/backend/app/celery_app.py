from celery import Celery
from backend.app.core.config import settings

celery_app = Celery("careerlens", broker=settings.redis_url, backend=settings.redis_url)
celery_app.conf.update(task_serializer="json", accept_content=["json"], result_serializer="json", timezone="UTC", enable_utc=True, task_acks_late=True, worker_prefetch_multiplier=1)
celery_app.autodiscover_tasks(["backend.app"])
